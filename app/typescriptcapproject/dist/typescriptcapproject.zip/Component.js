sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";const t=e.extend("typescriptcapproject.Component",{metadata:{manifest:"json"}});return t});
//# sourceMappingURL=Component.js.map