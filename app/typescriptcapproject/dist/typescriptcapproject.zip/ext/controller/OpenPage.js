sap.ui.define(["sap/m/MessageToast"],function(e){"use strict";function s(s){e.show("Custom handler invoked.")}var n={__esModule:true};n.OpenPage=s;return n});
//# sourceMappingURL=OpenPage.js.map